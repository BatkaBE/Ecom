import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/cart.dart';
import '../models/product_model.dart';

class ApiService {
  final String baseUrl = "https://fakestoreapi.com";

  Future<String?> login(String username, String password) async {
    final response = await http.post(
      Uri.parse("$baseUrl/auth/login"),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': username, 'password': password}),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['token'];
    }
    return null;
  }

  Future<int?> getUserIdByUsername(String username) async {
    final response = await http.get(Uri.parse("$baseUrl/users"));
    if (response.statusCode == 200) {
      List users = jsonDecode(response.body);
      final user = users.firstWhere(
        (user) => user['username'] == username,
        orElse: () => null,
      );
      return user != null ? user['id'] : null;
    }
    return null;
  }

  Future<List<dynamic>> getUserCart(int userId) async {
    final response = await http.get(Uri.parse("$baseUrl/carts/user/$userId"));
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    return [];
  }

  Future<Cart?> getCartByUserId(int userId) async {
    try {
      final response = await http.get(
        Uri.parse('https://fakestoreapi.com/carts/user/$userId'),
      );
      if (response.statusCode == 200) {
        final List<dynamic> cartsJson = jsonDecode(response.body);
        if (cartsJson.isNotEmpty) {
          return Cart.fromJson(cartsJson.last);
        }
      }
    } catch (e) {
      print('getCartByUserId error: $e');
    }
    return null;
  }

  Future<ProductModel?> getProductById(int id) async {
    try {
      final response = await http.get(
        Uri.parse("https://fakestoreapi.com/products/$id"),
      );
      if (response.statusCode == 200) {
        return ProductModel.fromJson(jsonDecode(response.body));
      }
    } catch (e) {
      print('getProductById error: $e');
    }
    return null;
  }

  Future<bool> addToServerCart(int userId, int productId, int quantity) async {
    try {
      final response = await http.post(
        Uri.parse('https://fakestoreapi.com/carts'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "userId": userId,
          "date": DateTime.now().toIso8601String().substring(0, 10),
          "products": [
            {"productId": productId, "quantity": quantity},
          ],
        }),
      );
      return response.statusCode == 200 || response.statusCode == 201;
    } catch (e) {
      print('addToServerCart error: $e');
      return false;
    }
  }

  Future<bool> updateServerCart(
    int cartId,
    List<Map<String, dynamic>> products,
  ) async {
    try {
      final response = await http.put(
        Uri.parse('https://fakestoreapi.com/carts/$cartId'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "date": DateTime.now().toIso8601String().substring(0, 10),
          "products": products,
        }),
      );
      return response.statusCode == 200;
    } catch (e) {
      print('updateServerCart error: $e');
      return false;
    }
  }
}
