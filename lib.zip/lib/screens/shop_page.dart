import 'dart:convert';
import 'package:flutter/material.dart';
import '../models/product_model.dart';
import '../widgets/product_view_shop.dart';

class ShopPage extends StatefulWidget {
  const ShopPage({Key? key}) : super(key: key);

  @override
  State<ShopPage> createState() => _ShopPageState();
}

class _ShopPageState extends State<ShopPage> {
  late final Future<List<ProductModel>> _futureData;

  @override
  void initState() {
    super.initState();
    _futureData = _getData();
  }

  Future<List<ProductModel>> _getData() async {
    final res = await DefaultAssetBundle.of(
      context,
    ).loadString('assets/products.json');
    final data = ProductModel.fromList(json.decode(res));
    return data;
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<ProductModel>>(
      future: _futureData,
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final items = snapshot.data!;
        return SingleChildScrollView(
          padding: const EdgeInsets.only(top: 10, left: 10),
          child: Wrap(
            spacing: 20,
            runSpacing: 10,
            children: items
                .map((item) => ProductViewShop(item))
                .toList(growable: false),
          ),
        );
      },
    );
  }
}
