import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/product_model.dart';
import '../provider/globalProvider.dart';

class ProductDetail extends StatelessWidget {
  final ProductModel product;
  const ProductDetail(this.product, {super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<GlobalProvider>(
      builder: (context, provider, _) {
        return Scaffold(
          appBar: AppBar(title: Text(product.title!)),
          body: Center(
            child: Column(
              children: [
                Image.network(product.image!, height: 200),
                const SizedBox(height: 16),
                Text(
                  product.title!,
                  style: const TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  product.description!,
                  style: const TextStyle(fontSize: 16),
                ),
                const SizedBox(height: 8),
                Text(
                  'PRICE: \$${product.price}',
                  style: const TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          floatingActionButton: FloatingActionButton(
            onPressed: () => provider.addToCart(product),
            child: const Icon(Icons.shopping_cart),
          ),
        );
      },
    );
  }
}
