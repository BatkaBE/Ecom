// lib/screens/profile_page.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../provider/globalProvider.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Load users once when dependencies change
    Provider.of<GlobalProvider>(context, listen: false).loadUsers();
  }

  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<GlobalProvider>(context);

    // Хэрвээ нэвтрээгүй бол зөвхөн мэдээлэл харуулна
    if (prov.currentUser == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('My Profile')),
        body: const Center(
          child: Text('Та нэвтрээгүй байна.', style: TextStyle(fontSize: 18)),
        ),
      );
    }

    // If logged in, show profile
    final user = prov.currentUser!;
    return Scaffold(
      appBar: AppBar(title: const Text('My Profile')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 50,
                backgroundImage:
                    user.avatarUrl != null
                        ? NetworkImage(user.avatarUrl!)
                        : null,
                child:
                    user.avatarUrl == null
                        ? const Icon(Icons.person, size: 50)
                        : null,
              ),
              const SizedBox(height: 16),
              Text(
                '${user.name.firstname} ${user.name.lastname}',
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(user.email, style: const TextStyle(fontSize: 16)),
              const SizedBox(height: 4),
              Text(user.phone, style: const TextStyle(fontSize: 16)),
              const SizedBox(height: 4),
              Text(
                '${user.address.city}, ${user.address.street}',
                style: const TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 24),
              // --- Хэлний сонголтын цэс ---
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.language),
                  const SizedBox(width: 8),
                  DropdownButton<String>(
                    value: prov.locale.languageCode,
                    items: const [
                      DropdownMenuItem(value: 'en', child: Text('English')),
                      DropdownMenuItem(value: 'mn', child: Text('Монгол')),
                    ],
                    onChanged: (value) {
                      if (value != null) {
                        prov.setLocale(value);
                      }
                    },
                  ),
                ],
              ),
              Expanded(child: SizedBox()),
            ],
          ),
        ),
      ),
    );
  }
}
