import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../provider/globalProvider.dart';

class BagsPage extends StatelessWidget {
  const BagsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<GlobalProvider>(
      builder: (context, provider, _) {
        final items = provider.cartItems;
        if (items.isEmpty) {
          return Scaffold(
            appBar: AppBar(
              title: Text(provider.localizedStrings['cart'] ?? 'Cart'),
            ),
            body: const Center(child: Text('Сагс хоосон байна')),
          );
        }
        return Scaffold(
          appBar: AppBar(title: Text(provider.localizedStrings['cart'] ?? 'Cart')),
          body: ListView.builder(
            itemCount: items.length,
            itemBuilder: (context, i) {
              final item = items[i];
              return Card(
                margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
                child: ListTile(
                  leading: Image.network(item.image!, width: 50, height: 50),
                  title: Text(item.title!),
                  subtitle: Text(
                    '₮${(item.price! * item.count).toStringAsFixed(2)}',
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.remove_circle_outline),
                        onPressed: () => provider.decreaseQuantity(item),
                      ),
                      Text('${item.count}'),
                      IconButton(
                        icon: const Icon(Icons.add_circle_outline),
                        onPressed: () => provider.increaseQuantity(item),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () => provider.removeFromCart(item),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
          bottomNavigationBar: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Нийт: ₮${provider.cartTotal.toStringAsFixed(2)}',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    // TODO: Checkout logic
                  },
                  child: const Text('Buy All'),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
