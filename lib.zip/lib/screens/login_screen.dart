import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart';
import '../services/api_service.dart';
import '../provider/globalProvider.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  final ApiService apiService = ApiService();

  void login() async {
    final username = _usernameController.text.trim();
    final password = _passwordController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Нэвтрэх нэр болон нууц үгээ бөглөнө үү")),
      );
      return;
    }

    final globalProvider = Provider.of<GlobalProvider>(context, listen: false);
    final success = await globalProvider.loginWithApi(
      username,
      password,
      apiService,
    );

    if (!mounted) return;

    if (success) {
      Navigator.pushReplacementNamed(context, '/shop');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Нэвтрэх нэр эсвэл нууц үг буруу байна")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Login")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _usernameController,
              decoration: InputDecoration(labelText: 'Username'),
            ),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(onPressed: login, child: Text("Нэвтрэх")),
          ],
        ),
      ),
    );
  }
}
