import 'package:json_annotation/json_annotation.dart';
part 'user_model.g.dart';

@JsonSerializable(createToJson: false)
class Geolocation {
  final String lat;
  @JsonKey(name: 'long')
  final String long;

  Geolocation({required this.lat, required this.long});
  factory Geolocation.fromJson(Map<String, dynamic> json) =>
      _$GeolocationFromJson(json);
}

@JsonSerializable(createToJson: false, explicitToJson: true)
class Address {
  final Geolocation geolocation;
  final String city;
  final String street;
  final int number;
  final String zipcode;

  Address({
    required this.geolocation,
    required this.city,
    required this.street,
    required this.number,
    required this.zipcode,
  });
  factory Address.fromJson(Map<String, dynamic> json) =>
      _$AddressFromJson(json);
}

@JsonSerializable(createToJson: false)
class NameModel {
  final String firstname;
  final String lastname;

  NameModel({required this.firstname, required this.lastname});
  factory NameModel.fromJson(Map<String, dynamic> json) =>
      _$NameModelFromJson(json);
}

@JsonSerializable(createToJson: false, explicitToJson: true)
class UserModel {
  final int id;
  final String email;
  final String username;
  final String password;
  final NameModel name;
  final String phone;
  final Address address;
  final String? avatarUrl;

  UserModel({
    required this.id,
    required this.email,
    required this.username,
    required this.password,
    required this.name,
    required this.phone,
    required this.address,
    this.avatarUrl,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) =>
      _$UserModelFromJson(json);

  /// helper to load a list
  static List<UserModel> fromList(List<dynamic> data) =>
      data.map((e) => UserModel.fromJson(e as Map<String, dynamic>)).toList();
}
