import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shop/services/api_service.dart';
import '../models/product_model.dart';
import '../models/user_model.dart';
import '../models/cart.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class GlobalProvider extends ChangeNotifier {
  final ApiService apiService = ApiService();

  // PRODUCTS
  List<ProductModel> products = [];

  Future<void> loadProducts() async {
    final jsonStr = await rootBundle.loadString('assets/products.json');
    final List<dynamic> list = json.decode(jsonStr);
    products = ProductModel.fromList(list);
    notifyListeners();
  }

  /// JSON-аас авсан бүтээгдэхүүний жагсаалтыг шууд оруулж, notify хийнэ
  ///
  void setProducts(List<ProductModel> data) {
    products = data;
    notifyListeners();
  }

  /// (Optional) Direct setter for ShopPage
  ///
  /// @deprecated
  // CART
  /// Серверээс тухайн хэрэглэгчийн cart-ийг userId-аар авах функц
  Future<Cart?> getCartByUserId(int userId) async {
    try {
      final response = await http.get(
        Uri.parse('https://fakestoreapi.com/carts/user/$userId'),
      );
      if (response.statusCode == 200) {
        final List<dynamic> cartsJson = jsonDecode(response.body);
        if (cartsJson.isNotEmpty) {
          // Хамгийн сүүлийн cart-ийг буцаана
          return Cart.fromJson(cartsJson.last);
        }
      }
    } catch (e) {
      print('getCartByUserId error: $e');
    }
    return null;
  }

  final List<ProductModel> _cartItems = [];
  Future<void> loadUserCart() async {
    print('loadUserCart called, carts length: ${carts.length}');
    print('carts: $carts');
    if (carts.isEmpty) {
      print('No carts, cartItems cleared');
      _cartItems.clear();
      notifyListeners();
      return;
    }
    convertCartProducts(carts[0]).then((value) {
      print('convertCartProducts finished, value: $value');
      _cartItems.clear();
      _cartItems.addAll(value);
      notifyListeners();
      print('Cart loaded, cartItems: $_cartItems');
    });
  }

  List<Cart> carts = []; // серверээс авсан

  // Ирсэн cart-аас productId-г ашиглан мэдээлэл татах
  Future<ProductModel?> getProductById(int id) async {
    return await apiService.getProductById(id);
  }

  // Серверээс cart-аас local cart-д хөрвүүлэх функц
  Future<List<ProductModel>> convertCartProducts(Cart cart) async {
    List<ProductModel> products = [];
    for (CartProduct item in cart.products) {
      ProductModel? product = await apiService.getProductById(item.productId);
      if (product != null) {
        products.add(product);
      }
    }
    return products;
  }

  List<ProductModel> get cartItems => List.unmodifiable(_cartItems);

  void addToCart(ProductModel item) {
    if (!_cartItems.any((p) => p.id == item.id)) {
      item.count = 1;
      _cartItems.add(item);
      notifyListeners();
      // Серверт хадгалах
      final prefs = SharedPreferences.getInstance();
      prefs.then((value) {
        final userId = value.getInt('userId');
        if (userId != null) {
          apiService.addToServerCart(userId, item.id!, item.count);
          print('Added to server cart: ${item.id}');
        }
      });
    }
  }

  void removeFromCart(ProductModel item) {
    _cartItems.removeWhere((p) => p.id == item.id);
    notifyListeners();
  }

  void increaseQuantity(ProductModel item) {
    final p = _cartItems.firstWhere((p) => p.id == item.id);
    p.count++;
    notifyListeners();
  }

  void decreaseQuantity(ProductModel item) {
    final p = _cartItems.firstWhere((p) => p.id == item.id);
    p.count--;
    if (p.count <= 0) _cartItems.remove(p);
    notifyListeners();
  }

  double get cartTotal =>
      _cartItems.fold(0, (sum, item) => sum + (item.price! * item.count));

  // FAVORITES
  final List<ProductModel> _favorites = [];
  List<ProductModel> get favorites => List.unmodifiable(_favorites);

  void toggleFavorite(ProductModel item) {
    if (_favorites.any((p) => p.id == item.id)) {
      _favorites.removeWhere((p) => p.id == item.id);
    } else {
      _favorites.add(item);
    }
    notifyListeners();
  }

  bool isFavorite(ProductModel item) => _favorites.any((p) => p.id == item.id);

  // AUTHENTICATION
  final List<UserModel> _users = [];
  UserModel? currentUser;

  /// Load users from JSON asset
  Future<void> loadUsers() async {
    final jsonStr = await rootBundle.loadString('assets/users.json');
    final List<dynamic> list = json.decode(jsonStr);
    _users
      ..clear()
      ..addAll(UserModel.fromList(list));
  }

  Future<bool> loginWithApi(
    String username,
    String password,
    ApiService apiService,
  ) async {
    final token = await apiService.login(username, password);
    if (token == null) return false;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('token', token);

    int? userId = await apiService.getUserIdByUsername(username);
    if (userId == null) return false;
    await prefs.setInt('userId', userId);

    // --- Хэрэглэгчийн мэдээллийг олж currentUser-д оноох ---
    if (_users.isEmpty) {
      await loadUsers();
    }
    final user =
        _users.where((u) => u.id == userId).cast<UserModel?>().firstOrNull;
    if (user != null) {
      currentUser = user;
    }

    // Серверээс тухайн хэрэглэгчийн cart-ийг авна
    final userCart = await getCartByUserId(userId);
    if (userCart != null) {
      carts = [userCart];
    } else {
      carts = [];
    }
    await loadUserCart();

    notifyListeners();
    return true;
  }

  // NAVIGATION
  int currentIdx = 0;
  void changeCurrentIdx(int idx) {
    currentIdx = idx;
    notifyListeners();
  }

  // хэлний тохиргоо
  Locale _locale = const Locale('en');
  Locale get locale => _locale;

  Map<String, String> localizedStrings = {};

  Future<void> loadLocale() async {
    final prefs = await SharedPreferences.getInstance();
    final langCode = prefs.getString('language_code') ?? 'en';
    _locale = Locale(langCode);

    // Хэлний JSON-оос утга ачаална
    final jsonStr = await rootBundle.loadString('assets/lan/$langCode.json');
    final Map<String, dynamic> jsonMap = json.decode(jsonStr);
    localizedStrings = jsonMap.map(
      (key, value) => MapEntry(key, value.toString()),
    );

    notifyListeners();
  }

  Future<void> setLocale(String languageCode) async {
    _locale = Locale(languageCode);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('language_code', languageCode);

    // Хэлний JSON-оос утга ачаална
    final jsonStr = await rootBundle.loadString(
      'assets/lan/$languageCode.json',
    );
    final Map<String, dynamic> jsonMap = json.decode(jsonStr);
    localizedStrings = jsonMap.map(
      (key, value) => MapEntry(key, value.toString()),
    );

    notifyListeners();
  }
}
