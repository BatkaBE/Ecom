import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'provider/globalProvider.dart';
import 'screens/home_page.dart';
import 'screens/login_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final globalProvider = GlobalProvider();
  await globalProvider.loadLocale();
  runApp(ChangeNotifierProvider(create: (_) => globalProvider, child: MyApp()));
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<GlobalProvider>(context);
    return MaterialApp(
      initialRoute: '/login',
      routes: {'/login': (_) => LoginScreen(), '/shop': (_) => HomePage()},
      locale: provider.locale,
      supportedLocales: const [Locale('en'), Locale('mn')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
    );
  }
}
